# CS546_A_Group_1_Project

<!-- re$ale -->
<!-- ABOUT THE PROJECT -->

## About re$ume builder

<!-- How to run re$ume builder -->

## How to install and run

Follow the steps to run Resume Builder.

1. Fork the Project / Download the source code as a zip file
2. Navigate to the project directory
3. Install the dependencies (`npm install`)
4. Seed the database (`npm run seed`)
5. Start the server (`npm start`)
6. Navigate to `localhost: 3000`

<!-- CONTRIBUTING -->

## Contributing

If you have to add a feature, please fork the repo and create a pull request.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/Feature`)
3. Commit your Changes (`git commit -m 'Adding Feature'`)
4. Push to the Branch (`git push origin feature/Feature`)
5. Open a Pull Request

<p align="right">(<a href="#top">back to top</a>)</p>
