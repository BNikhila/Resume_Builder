const users = require("./users");
const resume = require("./resume");
const conatctus = require("./contact-us");

module.exports = {
  users,
  resume,
  conatctus
};
