const users = require("./users");
const resume = require("./resume");
const coverletter = require("./coverletter");
const cv = require("./cv");
const conatctus = require("./contact-us");

module.exports = {
  users,
  resume,
  conatctus,
  coverletter,
  cv
};
